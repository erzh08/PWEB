var eventos = require("events");
var Emissor = eventos.EventEmitter;
var ee = new Emissor();
ee.on('dados', (x) => {
    console.log(x);
});
setInterval(() => {
    ee.emit('dados', Date.now());
}, 500);