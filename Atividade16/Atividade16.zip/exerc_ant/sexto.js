var page = "<html><body>Site da Cagada</body></html>";
var http = require("http");

var server = http.createServer((req, ans) => {
    var opc = req.url;
    if(opc == "/historia")
        ans.end(page.replace("Cagada", "Historia"));
    else if(opc == "/cursos")
        ans.end(page.replace("Cagada", "Cursos"));
    else if(opc == "/professores")
        ans.end(page.replace("Cagada", "Professores"));
    else
    ans.end(page.replace("Site da Cagada", "404"));
});
server.listen(3000);