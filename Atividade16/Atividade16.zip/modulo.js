var texto = "What is it";
module.exports = texto;