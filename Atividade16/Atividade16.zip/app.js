var app = require('./app/config/server');
var rotaHome = require('./app/routes/home');

/*rotaHome(app);
var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);

var rotaHistoria = require('./app/routes/historia'); // só está definindo
rotaHistoria(app); // está executando

var rotaCursos = require('./app/routes/cursos'); // só está definindo
rotaCursos(app); // está executando

var rotaProfessores = require('./app/routes/professores'); // só está definindo
rotaProfessores(app); // está executando
*/

app.listen(3000, function(){
    console.log("servidor iniciado");
});

/*
var app = require('./app/config/server'); // carregando o módulo do servidor
app.get('/', (req,res) => {
    res.render("home/index");
});

app.get('/formulario_adicionar_usuario', (req,res) => {
    res.render("admin/adicionar_usuario");
});

app.get('/informacao/historia', (req,res) => {
    res.render("informacao/historia");
});

app.get('/informacao/cursos', (req,res) => {
    res.render("informacao/cursos")
});

app.get('/informacao/professores', (req,res) => {
    res.render("informacao/professores");
});

app.listen(3000, () => {
    console.log("servidor iniciado");
});
*/

/*
var express = require("express");
var modulo = require("./modulo");
var app = express();

app.set("view engine", "ejs");

app.get("/", (req, ans) => {
    ans.render("home/index");
});

app.get("/form_add_usuario", (req, ans) => {
    ans.render("admin/adicionar_usuario");
});

app.get("/historia", (req, ans) => {
    ans.render("informacao/historia");
});
        
app.get("/cursos", (req, ans) => {
    ans.render("informacao/cursos");
});
        
app.get("/professores", (req, ans) => {
    ans.render("informacao/professores");
});

app.listen(3000, () => {
    console.log(modulo);
});
*/