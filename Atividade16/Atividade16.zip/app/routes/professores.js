const sql = require("mssql");
var dbConnection = require('../config/db_connection');

module.exports = function(app){
    app.get('/informacao/professores', function(req,res){
        async function getProfessores() {
            try {
                const pool = await dbConnection(); // executando a funcao
                const results = await pool.request().query('SELECT * from PROFESSORES');
                res.render('informacao/professores', {profs : results.recordset});
            } catch (err) {
                console.log(err);
            }
        }
        const professores = getProfessores();
    });
};