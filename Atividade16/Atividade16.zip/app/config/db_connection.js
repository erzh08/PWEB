var sql = require ('mssql/msnodesqlv8');
module.exports = function(){
    const config = {
        user: 'BD2013025',
        password: 'Sintellisense!ERR@R',
        database: 'BD', //your database
        server: '192.168.1.6',
        driver: 'msnodesqlv8',
    }
    return sql.connect(config);
}